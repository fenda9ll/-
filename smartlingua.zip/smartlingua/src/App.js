import React, { useState } from "react";
import './index.css';

const examplePrompts = [
  "What do you usually eat for breakfast?",
  "Describe your favorite place to travel.",
  "What kind of movies do you enjoy?",
  "Tell me about your daily routine.",
  "What do you like to do on weekends?",
];

const exampleHints = [
  ["eggs", "toast", "I prefer", "because it makes me feel"],
  ["beach", "mountains", "I love", "because it's relaxing"],
  ["action", "comedy", "I like watching", "they make me laugh"],
  ["wake up", "brush my teeth", "go to work", "in the evening"],
  ["hang out", "relax", "watch TV", "go hiking"],
];

function App() {
  const [step, setStep] = useState(0);
  const [userInput, setUserInput] = useState("");
  const [history, setHistory] = useState([]);
  const [feedback, setFeedback] = useState("");

  const handleSubmit = () => {
    const currentPrompt = examplePrompts[step];
    const mockFeedback = `Great start! Try saying: "${userInput} because..."`;
    const mockGrammar = "Present Simple";

    setHistory(prev => [
      ...prev,
      { question: currentPrompt, answer: userInput, feedback: mockFeedback, grammar: mockGrammar }
    ]);

    setUserInput("");
    setFeedback(mockFeedback);
    setStep(prev => prev + 1);
  };

  const currentPrompt = examplePrompts[step];
  const currentHints = exampleHints[step];

  return (
    <div className="max-w-xl mx-auto mt-10 p-4 text-gray-900">
      <h1 className="text-2xl font-bold mb-4">SmartLingua OS</h1>

      {step < 5 ? (
        <div>
          <p className="mb-2 font-semibold">🧠 Round {step + 1}/5:</p>
          <p className="mb-4">{currentPrompt}</p>

          <input
            type="text"
            className="w-full border p-2 rounded mb-2"
            placeholder="Your answer in English..."
            value={userInput}
            onChange={(e) => setUserInput(e.target.value)}
          />

          <div className="mb-4 text-sm text-gray-600">
            💡 Hints: {currentHints.map((h, i) => (
              <span key={i} className="mr-2 bg-gray-200 px-2 py-1 rounded">{h}</span>
            ))}
          </div>

          <button onClick={handleSubmit} className="bg-blue-600 text-white px-4 py-2 rounded">Submit</button>
        </div>
      ) : (
        <p className="text-green-600 font-semibold">🎉 You've completed this session!</p>
      )}

      {feedback && (
        <div className="mt-6">
          <h2 className="font-semibold">📝 Feedback:</h2>
          <p>{feedback}</p>
        </div>
      )}

      <div className="mt-6">
        <h2 className="font-semibold mb-2">📚 Round History:</h2>
        <ul className="list-disc pl-5 space-y-2">
          {history.map((h, i) => (
            <li key={i}>
              <strong>Q:</strong> {h.question}<br />
              <strong>You:</strong> {h.answer}<br />
              <strong>AI:</strong> {h.feedback}<br />
              <strong>Grammar:</strong> {h.grammar}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

export default App;